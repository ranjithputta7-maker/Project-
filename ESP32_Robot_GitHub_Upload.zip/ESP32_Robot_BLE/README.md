# ESP32 Robot BLE Code

## Files
- `ESP32_Robot_BLE.ino` — ESP32 Arduino sketch.

## Upload to GitHub
1. Open your GitHub repository.
2. Tap **Add file** → **Upload files**.
3. Select this ZIP after extracting it, or upload `ESP32_Robot_BLE.ino` directly.
4. Tap **Commit changes**.

## Notes
- Board target: ESP32 (Arduino IDE).
- The sketch uses the ESP32 BLE library and Arduino functions such as `analogWrite`, `tone`, and `pulseIn`.
- Check that your motor driver, sensor, and buzzer wiring matches the pin definitions in the sketch before powering the robot.
- Test with the wheels safely raised and the robot switched off while changing wiring.
